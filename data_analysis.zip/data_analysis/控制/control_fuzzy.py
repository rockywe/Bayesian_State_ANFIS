import numpy as np
import matplotlib.pyplot as plt
import skfuzzy as fuzz
from skfuzzy import control as ctrl
from scipy.special import erf

# Constants
Ns = 31
r1 = 42e-3
r2 = 146e-3
h = 20e-3
P = 101.325  # kPa
H = 709.1735  # Kpa*m3/mol

# Specific surface area of packing
a = 500  # m2/m3

# Volume of packing
v = np.pi * (r2**2 - r1**2) * (20e-3)

# Cross-sectional area
aa = np.pi * (1.6e-3)**2  # 16#

# Superoxygen concentration
c_oo2 = 7e-9  # mol/l

# Rate constant k_no-ooh
k_nooo2 = 6.9e9

# Apparent rate constant
k_appi = k_nooo2 * c_oo2

r = np.sqrt(r1 * r2)
D_no = 2.21e-9

gn2 = 2 / 3600
y_in = 0.0005

# Define fuzzy variables
error = ctrl.Antecedent(np.arange(-0.05, 0.05, 0.01), 'error')
delta_error = ctrl.Antecedent(np.arange(-0.01, 0.01, 0.002), 'delta_error')
rpm_change = ctrl.Consequent(np.arange(-50, 50, 10), 'rpm_change')
flow_change = ctrl.Consequent(np.arange(-1e-9, 1e-9, 2e-10), 'flow_change')

# Define membership functions for error
error['neg'] = fuzz.trimf(error.universe, [-0.05, -0.05, 0])
error['zero'] = fuzz.trimf(error.universe, [-0.05, 0, 0.05])
error['pos'] = fuzz.trimf(error.universe, [0, 0.05, 0.05])

# Define membership functions for delta_error
delta_error['neg'] = fuzz.trimf(delta_error.universe, [-0.01, -0.01, 0])
delta_error['zero'] = fuzz.trimf(delta_error.universe, [-0.01, 0, 0.01])
delta_error['pos'] = fuzz.trimf(delta_error.universe, [0, 0.01, 0.01])

# Define membership functions for rpm_change
rpm_change['decrease'] = fuzz.trimf(rpm_change.universe, [-50, -50, 0])
rpm_change['no_change'] = fuzz.trimf(rpm_change.universe, [-50, 0, 50])
rpm_change['increase'] = fuzz.trimf(rpm_change.universe, [0, 50, 50])

# Define membership functions for flow_change
flow_change['decrease'] = fuzz.trimf(flow_change.universe, [-1e-9, -1e-9, 0])
flow_change['no_change'] = fuzz.trimf(flow_change.universe, [-1e-9, 0, 1e-9])
flow_change['increase'] = fuzz.trimf(flow_change.universe, [0, 1e-9, 1e-9])

# Define fuzzy rules
rule1 = ctrl.Rule(error['neg'] & delta_error['neg'], [rpm_change['increase'], flow_change['increase']])
rule2 = ctrl.Rule(error['neg'] & delta_error['zero'], [rpm_change['increase'], flow_change['increase']])
rule3 = ctrl.Rule(error['neg'] & delta_error['pos'], [rpm_change['no_change'], flow_change['no_change']])
rule4 = ctrl.Rule(error['zero'] & delta_error['neg'], [rpm_change['no_change'], flow_change['no_change']])
rule5 = ctrl.Rule(error['zero'] & delta_error['zero'], [rpm_change['no_change'], flow_change['no_change']])
rule6 = ctrl.Rule(error['zero'] & delta_error['pos'], [rpm_change['no_change'], flow_change['no_change']])
rule7 = ctrl.Rule(error['pos'] & delta_error['neg'], [rpm_change['decrease'], flow_change['decrease']])
rule8 = ctrl.Rule(error['pos'] & delta_error['zero'], [rpm_change['decrease'], flow_change['decrease']])
rule9 = ctrl.Rule(error['pos'] & delta_error['pos'], [rpm_change['decrease'], flow_change['decrease']])

# Control system
rpm_control = ctrl.ControlSystem([rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9])
flow_control = ctrl.ControlSystem([rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9])

rpm_simulation = ctrl.ControlSystemSimulation(rpm_control)
flow_simulation = ctrl.ControlSystemSimulation(flow_control)

# Initial conditions
rpm = 400
l = 20e-3 / 3600  # l/s

# Target removal rate
target_remove = 0.985  # 目标脱除率（例如98.5%）

# Simulation parameters
dt = 1  # time step in seconds
num_steps = 100

# Data storage for plotting
time_data = []
rpm_data = []
flow_data = []
remove_data = []

# Simulation loop
for step in range(num_steps):
    # Liquid flow rate
    L = l / aa  # m/s

    # Ensure L is positive
    if L <= 0:
        L = 1e-6

    # Liquid film renewal time
    t_new = (r2 - r1) / (0.02107 * (L**0.2279) * ((r * rpm)**0.5448) * 31)

    # Ensure t_new is positive
    if t_new <= 0:
        t_new = 1e-6

    # Liquid film mass transfer coefficient
    kl1 = (np.sqrt(D_no * k_appi) / t_new) * (t_new * erf(np.sqrt(k_appi * t_new)) +
          np.sqrt((t_new / np.pi) / k_appi) * np.exp(-k_appi * t_new) +
          (0.5 / k_appi) * erf(np.sqrt(k_appi * t_new)))

    ky_cal = 0.082 * 298.15 * 0.2700 * kl1
    a1 = (1 - y_in) / y_in
    a2 = a * np.pi * h * (r2**2 - r1**2) / gn2
    yno = 1 / (a1 * np.exp(a2 * ky_cal) + 1)

    remove = (y_in - yno) / y_in

    # Fuzzy control adjustment
    error_value = target_remove - remove
    delta_error_value = error_value - (0 if step == 0 else (target_remove - remove_data[-1]))

    rpm_simulation.input['error'] = error_value
    rpm_simulation.input['delta_error'] = delta_error_value
    flow_simulation.input['error'] = error_value
    flow_simulation.input['delta_error'] = delta_error_value

    rpm_simulation.compute()
    flow_simulation.compute()

    rpm_adjustment = rpm_simulation.output['rpm_change']
    flow_adjustment = flow_simulation.output['flow_change']

    # Adjust rpm and flow rate based on fuzzy control output
    rpm = rpm+rpm_adjustment
    l += flow_adjustment

    # Ensure rpm and l are within valid ranges
    rpm = max(0, rpm)
    l = max(0, l)

    # Store data for plotting
    time_data.append(step * dt)
    rpm_data.append(rpm)
    flow_data.append(l)
    remove_data.append(remove)

    print(f"Step: {step}, RPM: {rpm:.2f}, Flow Rate: {l:.9f}, Removal: {remove:.4f}")

# Plotting results
plt.figure(figsize=(14, 7))

# Plot RPM
plt.subplot(3, 1, 1)
plt.plot(time_data, rpm_data, label='RPM', color='blue')
plt.xlabel('Time (s)')
plt.ylabel('RPM')
plt.title('RPM over Time')
plt.legend()

# Plot Flow Rate
plt.subplot(3, 1, 2)
plt.plot(time_data, flow_data, label='Flow Rate', color='green')
plt.xlabel('Time (s)')
plt.ylabel('Flow Rate (l/s)')
plt.title('Flow Rate over Time')
plt.legend()

# Plot Removal Rate
plt.subplot(3, 1, 3)
plt.plot(time_data, remove_data, label='Removal Rate', color='red')
plt.axhline(target_remove, color='grey', linestyle='--', label='Target Removal Rate')
plt.xlabel('Time (s)')
plt.ylabel('Removal Rate')
plt.title('Removal Rate over Time')
plt.legend()

plt.tight_layout()
plt.show()

