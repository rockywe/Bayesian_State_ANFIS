import sys

print(sys.path)
print(sys.version)