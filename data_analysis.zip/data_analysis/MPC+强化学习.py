import numpy as np

# 定义环境的步进函数
def environment_step(state, action):
    RPB_speed, H2O2_concentration, pH_value = state.flatten()
    if action == 0:
        RPB_speed -= 50
    elif action == 1:
        RPB_speed += 50
    RPB_speed = np.clip(RPB_speed, 200, 1600)  # 限制速度在200到1600之间

    # 更新后的状态
    next_state = np.array([[RPB_speed, H2O2_concentration, pH_value]])
    # 假设奖励函数：RPB速度越接近1200，奖励越高
    reward = -abs(RPB_speed - 1200)
    # 假设结束条件：RPB速度达到或超过1200
    done = (RPB_speed >= 1200)

    return next_state, reward, done

import random
from collections import deque
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# 构建DQN模型
def build_dqn_model(input_dim, output_dim):
    model = Sequential([
        Dense(64, input_dim=input_dim, activation='relu'),
        Dense(64, activation='relu'),
        Dense(output_dim, activation='linear')
    ])
    model.compile(optimizer='adam', loss='mse')
    return model

# 定义DQN代理
class DQNAgent:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95    # 折扣因子
        self.epsilon = 1.0   # 探索率
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.model = build_dqn_model(state_size, action_size)

    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def act(self, state):
        if np.random.rand() <= self.epsilon:
            return random.randrange(self.action_size)
        act_values = self.model.predict(state)
        return np.argmax(act_values[0])

    def replay(self, batch_size):
        minibatch = random.sample(self.memory, batch_size)
        for state, action, reward, next_state, done in minibatch:
            target = reward
            if not done:
                target = (reward + self.gamma *
                          np.amax(self.model.predict(next_state)[0]))
            target_f = self.model.predict(state)
            target_f[0][action] = target
            self.model.fit(state, target_f, epochs=1, verbose=0)
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

# 初始化
state_size = 3  # RPB速度, H2O2浓度, 吸收剂pH值
action_size = 3  # 控制变量数量：减少RPB速度，不变，增加RPB速度
agent = DQNAgent(state_size, action_size)
episodes = 1000
batch_size = 32

# 训练RL代理
for e in range(episodes):
    state = np.array([[800, 0.8, 12.5]])  # 初始状态
    for time in range(500):
        action = agent.act(state)
        next_state, reward, done = environment_step(state, action)
        agent.remember(state, action, reward, next_state, done)
        state = next_state
        if done:
            break
        if len(agent.memory) > batch_size:
            agent.replay(batch_size)

import casadi as ca

# 定义MPC问题
N = 10  # 预测时域长度
nx = 3  # 状态变量数量
nu = 3  # 控制变量数量

# CasADi变量
x = ca.MX.sym('x', nx)
u = ca.MX.sym('u', nu)
x_ref = ca.MX.sym('x_ref', nx)

# 神经网络预测函数
def nn_predict(x, u):
    input_data = np.hstack([x, u]).reshape(1, -1)
    return agent.model.predict(input_data)[0]

# 目标函数
cost = 0
g = []

for k in range(N):
    x_next = nn_predict(x, u)
    cost += ca.mtimes((x_next - x_ref).T, (x_next - x_ref))
    x = x_next

# 设置优化问题
opt_vars = ca.vertcat(*[u])
nlp = {'x': opt_vars, 'f': cost, 'g': ca.vertcat(*g)}

# 设置求解器
opts = {'ipopt.print_level': 0, 'print_time': 0}
solver = ca.nlpsol('solver', 'ipopt', nlp, opts)

# 初始条件
x0 = np.array([800, 0.8, 12.5])  # 当前NO去除效率
x_ref_val = np.array([1200, 1.0, 13.0])  # 期望状态
u0 = np.array([800, 0.8, 12.5])  # 初始控制输入

# 求解MPC问题
sol = solver(x0=u0, p=x_ref_val)
u_opt = sol['x'].full().flatten()

RPB_speed, H2O2_concentration, pH_value = u_opt

print(f"优化的控制输入 - RPB速度: {RPB_speed}, H2O2浓度: {H2O2_concentration}, 吸收剂pH值: {pH_value}")
