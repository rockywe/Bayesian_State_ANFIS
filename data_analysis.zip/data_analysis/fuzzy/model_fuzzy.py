import numpy as np
from scipy.special import erf
from scipy.linalg import pinv

# 定义参数
Ns = 31
r1 = 42e-3
r2 = 146e-3
h = 20e-3
P = 101.325 # kPa
H = 375.28 # Kpa*m3/mol

# 进液流量
l = 20e-3 / 3600 # l/s

# 填料比表面积
a = 500 # m2/m3

# 填料体积
v = 3.14 * (r2**2 - r1**2) * (20e-3)

# 截面积
aa = a * v
L = l / aa

# 速率常数
k_noooh = 103.4

# NO在溶液中的扩散系数
D_no = 2.21e-9

# 几何平均半径
r = np.sqrt(r1 * r2)

# 进气流量
gn2 = 2 / 3600
y_in = 0.0005
a1 = (1 - y_in) / y_in
a2 = a * 3.14 * h * (r2**2 - r1**2) / gn2

# 转速分布
rpm = np.array([400, 600, 800, 400, 600, 800, 400, 600, 800, 1200, 1200, 1000, 1200, 1400, 400, 600, 800, 400, 600, 800, 400, 600, 800, 1200, 1200, 1200, 1200, 1000, 1000, 1000, 1000, 200, 400, 600, 800, 200, 400, 600, 800, 1000, 1200, 1000, 1200, 800, 1000, 1200, 1000, 1200, 200, 400, 200, 400, 600, 800, 1000, 1200, 1400, 756, 1203, 1411, 800, 1000, 1200, 1400, 200, 400, 700, 1000, 1200, 1400])

# 无因次化
rpm1 = rpm / 800

# 吸收液pH值
pH = np.array([11.73, 11.73, 11.73, 11.86, 11.86, 11.86, 12.01, 12.01, 12.01, 12.01, 12.5, 12.5, 12.5, 12.5, 13, 13, 13, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 12.21, 12.21, 12.21, 12.21, 12.41, 12.41, 12.41, 12.41, 12.21, 12.21, 12.5, 12.5, 12.41, 13.5, 13.5, 13.5, 13.5, 12.81, 12.81, 13, 13, 13, 13, 13, 13, 13, 11.88, 11.88, 11.88, 11.69, 11.69, 11.69, 11.69, 11.65, 11.65, 11.65, 11.65, 11.65, 11.65])

# H2O2浓度
ch2o2 = np.array([0.05, 0.05, 0.05, 0.1, 0.1, 0.1, 0.4, 0.4, 0.4, 0.4, 0.05, 0.1, 0.1, 0.1, 0.05, 0.05, 0.05, 0.1, 0.1, 0.1, 0.4, 0.4, 0.4, 0.05, 0.1, 0.2, 0.4, 0.05, 0.1, 0.2, 0.4, 0.6, 0.6, 0.6, 0.6, 0.7, 0.7, 0.7, 0.7, 0.6, 0.6, 0.6, 0.6, 0.7, 0.6, 0.6, 0.8, 0.8, 0.8, 0.8, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])

# 计算y_out
y = np.array([0.357, 0.4864, 0.5512, 0.448, 0.5186, 0.5666, 0.7284, 0.7732, 0.7942, 0.8284, 0.47, 0.6213, 0.65, 0.6675, 0.437, 0.5664, 0.6312, 0.6678, 0.7395, 0.789, 0.768, 0.847, 0.895, 0.595, 0.81, 0.895, 0.935, 0.556, 0.765, 0.853, 0.899, 0.7812, 0.8602, 0.8832, 0.8968, 0.8032, 0.8914, 0.9032, 0.9133, 0.9132, 0.9178, 0.9207, 0.9269, 0.9069, 0.9568, 0.9639, 0.9589, 0.9687, 0.7636, 0.8712, 0.7345, 0.7856, 0.8093, 0.8312, 0.8968, 0.9236, 0.9312, 0.7578, 0.794, 0.8122, 0.6578, 0.7072, 0.729, 0.7532, 0.261, 0.403, 0.5636, 0.665, 0.6944, 0.7056])
y_out = y_in * (1 - y)

# 不同pH下的解离程度
al = 10**(11.73 - pH)
a = 1 / (1 + al)

# 氢过氧负离子浓度
ooh = ch2o2 * a

# 表观速率常数
k_appi = 103.4 * ooh

# 液膜更新时间
t_new = (r2 - r1) / (0.02107 * (L**0.2279) * ((r * rpm)**0.5448) * 31)
kl1 = (np.sqrt(D_no * k_appi) / t_new) * (t_new * erf(np.sqrt(k_appi * t_new)) + np.sqrt((t_new / np.pi) / k_appi) * np.exp(-k_appi * t_new) + (0.5 / k_appi) * erf(np.sqrt(k_appi * t_new)))
ky_cal = 0.082 * 298.15 * 0.2700 * kl1
yno = 1 / (a1 * np.exp(a2 * ky_cal) + 1)

# 实验值与拟合值之间的差异
error = y_out - yno

print("yno:", yno)
print("error:", error)

# 模糊隶属函数
def trimf(x, abc):
    a, b, c = abc
    return np.maximum(np.minimum((x - a) / (b - a), (c - x) / (c - b)), 0)

y1 = trimf(pH, [11.3, 11.8, 12.45])
y2 = trimf(pH, [12.3, 12.9, 13.7])

y3 = trimf(rpm, [190, 495, 760])
y4 = trimf(rpm, [750, 1320, 1700])

y5 = trimf(ch2o2, [0, 0.2, 0.5])
y6 = trimf(ch2o2, [0.4, 0.65, 0.85])
y7 = trimf(ch2o2, [0.8, 1.2, 1.70])

# 模糊规则隶属度
mem1 = y1 * y3 * y5
mem2 = y1 * y3 * y6
mem3 = y1 * y3 * y7
mem4 = y1 * y4 * y5
mem5 = y1 * y4 * y6
mem6 = y1 * y4 * y7

mem7 = y2 * y3 * y5
mem8 = y2 * y3 * y6
mem9 = y2 * y3 * y7
mem10 = y2 * y4 * y5
mem11 = y2 * y4 * y6
mem12 = y2 * y4 * y7

# 构建大矩阵
denom = mem1 + mem2 + mem3 + mem4 + mem5 + mem6 + mem7 + mem8 + mem9 + mem10 + mem11 + mem12
beta1 = mem1 / denom
beta2 = mem2 / denom
beta3 = mem3 / denom
beta4 = mem4 / denom
beta5 = mem5 / denom
beta6 = mem6 / denom
beta7 = mem7 / denom
beta8 = mem8 / denom
beta9 = mem9 / denom
beta10 = mem10 / denom
beta11 = mem11 / denom
beta12 = mem12 / denom

beta_1 = beta1 * pH
beta_2 = beta2 * pH
beta_3 = beta3 * pH
beta_4 = beta4 * pH
beta_5 = beta5 * pH
beta_6 = beta6 * pH
beta_7 = beta7 * pH
beta_8 = beta8 * pH
beta_9 = beta9 * pH
beta_10 = beta10 * pH
beta_11 = beta11 * pH
beta_12 = beta12 * pH

beta_11 = beta1 * rpm
beta_22 = beta2 * rpm
beta_33 = beta3 * rpm
beta_44 = beta4 * rpm
beta_55 = beta5 * rpm
beta_66 = beta6 * rpm
beta_77 = beta7 * rpm
beta_88 = beta8 * rpm
beta_99 = beta9 * rpm
beta_1010 = beta10 * rpm
beta_1111 = beta11 * rpm
beta_1212 = beta12 * rpm

beta_111 = beta1 * ch2o2
beta_222 = beta2 * ch2o2
beta_333 = beta3 * ch2o2
beta_444 = beta4 * ch2o2
beta_555 = beta5 * ch2o2
beta_666 = beta6 * ch2o2
beta_777 = beta7 * ch2o2
beta_888 = beta8 * ch2o2
beta_999 = beta9 * ch2o2
beta_101010 = beta10 * ch2o2
beta_111111 = beta11 * ch2o2
beta_121212 = beta12 * ch2o2

Z = np.zeros((len(pH), 48))
Z[:, 0] = beta1
Z[:, 1] = beta2
Z[:, 2] = beta3
Z[:, 3] = beta4
Z[:, 4] = beta5
Z[:, 5] = beta6
Z[:, 6] = beta7
Z[:, 7] = beta8
Z[:, 8] = beta9
Z[:, 9] = beta10
Z[:, 10] = beta11
Z[:, 11] = beta12

Z[:, 12] = beta_1
Z[:, 13] = beta_2
Z[:, 14] = beta_3
Z[:, 15] = beta_4
Z[:, 16] = beta_5
Z[:, 17] = beta_6
Z[:, 18] = beta_7
Z[:, 19] = beta_8
Z[:, 20] = beta_9
Z[:, 21] = beta_10
Z[:, 22] = beta_11
Z[:, 23] = beta_12

Z[:, 24] = beta_11
Z[:, 25] = beta_22
Z[:, 26] = beta_33
Z[:, 27] = beta_44
Z[:, 28] = beta_55
Z[:, 29] = beta_66
Z[:, 30] = beta_77
Z[:, 31] = beta_88
Z[:, 32] = beta_99
Z[:, 33] = beta_1010
Z[:, 34] = beta_1111
Z[:, 35] = beta_1212

Z[:, 36] = beta_111
Z[:, 37] = beta_222
Z[:, 38] = beta_333
Z[:, 39] = beta_444
Z[:, 40] = beta_555
Z[:, 41] = beta_666
Z[:, 42] = beta_777
Z[:, 43] = beta_888
Z[:, 44] = beta_999
Z[:, 45] = beta_101010
Z[:, 46] = beta_111111
Z[:, 47] = beta_121212

P = pinv(Z.T @ Z) @ Z.T @ error

# 模型预测
ph = 12.63
rr = 200
hh2o = 0.8

# 机理部分
# 解离度计算
al = 10**(11.73 - ph)
a = 1 / (1 + al)

# ooh活性粒子浓度
ooh1 = a * hh2o
k_appi = k_noooh * ooh1

# 液膜更新时间再计算
t_new = (r2 - r1) / (0.02107 * (L**0.2279) * ((r * rr)**0.5448) * 31)

# 液膜传质系数
kl1 = (np.sqrt(D_no * k_appi) / t_new) * (t_new * erf(np.sqrt(k_appi * t_new)) + np.sqrt((t_new / np.pi) / k_appi) * np.exp(-k_appi * t_new) + (0.5 / k_appi) * erf(np.sqrt(k_appi * t_new)))
ky_cal = 0.082 * 298.15 * 0.2700 * kl1
yno11 = 1 / (a1 * np.exp(a2 * ky_cal) + 1)

# 模糊模型部分
y11 = trimf(ph, [11.3, 11.8, 12.45])
y22 = trimf(ph, [12.3, 12.9, 13.7])

y33 = trimf(rr, [190, 495, 760])
y44 = trimf(rr, [750, 1320, 1700])

y55 = trimf(hh2o, [0, 0.2, 0.5])
y66 = trimf(hh2o, [0.4, 0.65, 0.85])
y77 = trimf(hh2o, [0.8, 1.2, 1.70])

mem11 = y11 * y33 * y55
mem22 = y11 * y33 * y66
mem33 = y11 * y33 * y77
mem44 = y11 * y44 * y55
mem55 = y11 * y44 * y66
mem66 = y11 * y44 * y77

mem77 = y22 * y33 * y55
mem88 = y22 * y33 * y66
mem99 = y22 * y33 * y77
mem101 = y22 * y44 * y55
mem111 = y22 * y44 * y66
mem121 = y22 * y44 * y77

yyy = (mem11 * (P[0] + P[12] * ph + P[24] * rr + P[36] * hh2o) +
       mem22 * (P[1] + P[13] * ph + P[25] * rr + P[37] * hh2o) +
       mem33 * (P[2] + P[14] * ph + P[26] * rr + P[38] * hh2o) +
       mem44 * (P[3] + P[15] * ph + P[27] * rr + P[39] * hh2o) +
       mem55 * (P[4] + P[16] * ph + P[28] * rr + P[40] * hh2o) +
       mem66 * (P[5] + P[17] * ph + P[29] * rr + P[41] * hh2o) +
       mem77 * (P[6] + P[18] * ph + P[30] * rr + P[42] * hh2o) +
       mem88 * (P[7] + P[19] * ph + P[31] * rr + P[43] * hh2o) +
       mem99 * (P[8] + P[20] * ph + P[32] * rr + P[44] * hh2o) +
       mem101 * (P[9] + P[21] * ph + P[33] * rr + P[45] * hh2o) +
       mem111 * (P[10] + P[22] * ph + P[34] * rr + P[46] * hh2o) +
       mem121 * (P[11] + P[23] * ph + P[35] * rr + P[47] * hh2o)) / \
       (mem11 + mem22 + mem33 + mem44 + mem55 + mem66 + mem77 + mem88 + mem99 + mem101 + mem111 + mem121)

# y脱除效率
y1111 = yno11 + yyy
y1 = 1 - (yno11 / 0.0005)
y_remo = 1 - (y1111 / 0.0005)

# 输出结果
print("y1:", y1)
print("y1111", y1111)
print("y_remo:", y_remo)
