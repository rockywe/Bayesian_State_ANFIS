import numpy as np
from scipy.special import erf
from scipy.linalg import pinv
import pandas as pd

# 定义物理常数和参数
ns = 31
inner_radius = 42e-3
outer_radius = 146e-3
height = 20e-3
pressure = 101.325 # kPa
henry_constant = 375.28 # kPa*m3/mol

# 进液流量 (m3/s)
liquid_flow_rate = 20e-3 / 3600

# 填料比表面积 (m2/m3)
specific_surface_area = 500

# 填料体积 (m3)
packing_volume = 3.14 * (outer_radius**2 - inner_radius**2) * height

# 有效比表面积 (m2)
effective_surface_area = specific_surface_area * packing_volume
L = liquid_flow_rate / effective_surface_area

# NO与OOH反应速率常数
reaction_rate_constant_no_ooh = 103.4

# NO在溶液中的扩散系数 (m2/s)
diffusion_coefficient_no = 2.21e-9

# 几何平均半径 (m)
average_radius = np.sqrt(inner_radius * outer_radius)

# 进气流量 (m3/s)
gas_flow_rate_n2 = 2 / 3600

# 初始气体浓度
y_in = 0.0005
a1 = (1 - y_in) / y_in
a2 = specific_surface_area * 3.14 * height * (outer_radius**2 - inner_radius**2) / gas_flow_rate_n2

data = pd.read_excel('no.xlsx')
print(data.head())
rpm_values = data['rpm']
# print(rpm_values)
ph_values = data['ph']
h2o2_concentration = data['ch2o2']
flow_rate = data['flow_rate']
measured_y = data['y']

# 转速分布
# rpm_values = np.array([400, 600, 800, 400, 600, 800, 400, 600, 800, 1200, 1200, 1000, 1200, 1400, 400, 600, 800, 400, 600, 800, 400, 600, 800, 1200, 1200, 1200, 1200, 1000, 1000, 1000, 1000, 200, 400, 600, 800, 200, 400, 600, 800, 1000, 1200, 1000, 1200, 800, 1000, 1200, 1000, 1200, 200, 400, 200, 400, 600, 800, 1000, 1200, 1400, 756, 1203, 1411, 800, 1000, 1200, 1400, 200, 400, 700, 1000, 1200, 1400])

# 转速无因次化
rpm_normalized = rpm_values / 800

# 吸收液pH值
# ph_values = np.array([11.73, 11.73, 11.73, 11.86, 11.86, 11.86, 12.01, 12.01, 12.01, 12.01, 12.5, 12.5, 12.5, 12.5, 13, 13, 13, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 13.5, 12.21, 12.21, 12.21, 12.21, 12.41, 12.41, 12.41, 12.41, 12.21, 12.21, 12.5, 12.5, 12.41, 13.5, 13.5, 13.5, 13.5, 12.81, 12.81, 13, 13, 13, 13, 13, 13, 13, 11.88, 11.88, 11.88, 11.69, 11.69, 11.69, 11.69, 11.65, 11.65, 11.65, 11.65, 11.65, 11.65])

# H2O2浓度
# h2o2_concentration = np.array([0.05, 0.05, 0.05, 0.1, 0.1, 0.1, 0.4, 0.4, 0.4, 0.4, 0.05, 0.1, 0.1, 0.1, 0.05, 0.05, 0.05, 0.1, 0.1, 0.1, 0.4, 0.4, 0.4, 0.05, 0.1, 0.2, 0.4, 0.05, 0.1, 0.2, 0.4, 0.6, 0.6, 0.6, 0.6, 0.7, 0.7, 0.7, 0.7, 0.6, 0.6, 0.6, 0.6, 0.7, 0.6, 0.6, 0.8, 0.8, 0.8, 0.8, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])

# 计算出口浓度y_out
# measured_y = np.array([0.357, 0.4864, 0.5512, 0.448, 0.5186, 0.5666, 0.7284, 0.7732, 0.7942, 0.8284, 0.47, 0.6213, 0.65, 0.6675, 0.437, 0.5664, 0.6312, 0.6678, 0.7395, 0.789, 0.768, 0.847, 0.895, 0.595, 0.81, 0.895, 0.935, 0.556, 0.765, 0.853, 0.899, 0.7812, 0.8602, 0.8832, 0.8968, 0.8032, 0.8914, 0.9032, 0.9133, 0.9132, 0.9178, 0.9207, 0.9269, 0.9069, 0.9568, 0.9639, 0.9589, 0.9687, 0.7636, 0.8712, 0.7345, 0.7856, 0.8093, 0.8312, 0.8968, 0.9236, 0.9312, 0.7578, 0.794, 0.8122, 0.6578, 0.7072, 0.729, 0.7532, 0.261, 0.403, 0.5636, 0.665, 0.6944, 0.7056])

y_out = y_in * (1 - measured_y)

# 计算不同pH下的解离程度
dissociation_degree = 10**(11.73 - ph_values)
alpha = 1 / (1 + dissociation_degree)

# 氢过氧负离子浓度
ooh_concentration = h2o2_concentration * alpha

# 表观速率常数
apparent_rate_constant = reaction_rate_constant_no_ooh * ooh_concentration

# 液膜更新时间计算
liquid_film_update_time = (outer_radius - inner_radius) / (0.02107 * (L**0.2279) * ((average_radius * rpm_values)**0.5448) * ns)

# 液膜传质系数
kl1 = (np.sqrt(diffusion_coefficient_no * apparent_rate_constant) / liquid_film_update_time) * (
    liquid_film_update_time * erf(np.sqrt(apparent_rate_constant * liquid_film_update_time)) +
    np.sqrt((liquid_film_update_time / np.pi) / apparent_rate_constant) * np.exp(-apparent_rate_constant * liquid_film_update_time) +
    (0.5 / apparent_rate_constant) * erf(np.sqrt(apparent_rate_constant * liquid_film_update_time))
)
ky_calculated = 0.082 * 298.15 * 0.2700 * kl1
yno_calculated = 1 / (a1 * np.exp(a2 * ky_calculated) + 1)

# 实验值与拟合值之间的差异
error = y_out - yno_calculated

print("yno_calculated:", yno_calculated)
print("error:", error)

# 定义模糊隶属函数
def trimf(x, abc):
    a, b, c = abc
    return np.maximum(np.minimum((x - a) / (b - a), (c - x) / (c - b)), 0)

# pH值模糊化
y1 = trimf(ph_values, [11.3, 11.8, 12.45])
y2 = trimf(ph_values, [12.3, 12.9, 13.7])

# 转速模糊化
y3 = trimf(rpm_values, [190, 495, 760])
y4 = trimf(rpm_values, [750, 1320, 1700])

# H2O2浓度模糊化
y5 = trimf(h2o2_concentration, [0, 0.2, 0.5])
y6 = trimf(h2o2_concentration, [0.4, 0.65, 0.85])
y7 = trimf(h2o2_concentration, [0.8, 1.2, 1.70])

# 模糊规则隶属度
membership1 = y1 * y3 * y5
membership2 = y1 * y3 * y6
membership3 = y1 * y3 * y7
membership4 = y1 * y4 * y5
membership5 = y1 * y4 * y6
membership6 = y1 * y4 * y7

membership7 = y2 * y3 * y5
membership8 = y2 * y3 * y6
membership9 = y2 * y3 * y7
membership10 = y2 * y4 * y5
membership11 = y2 * y4 * y6
membership12 = y2 * y4 * y7

# 计算模糊规则隶属度和模型系数
denominator = (membership1 + membership2 + membership3 + membership4 + membership5 + membership6 +
              membership7 + membership8 + membership9 + membership10 + membership11 + membership12)

beta = np.zeros((12, len(ph_values)))
for i in range(12):
    beta[i] = locals()[f'membership{i+1}'] / denominator

# 模型矩阵构建
Y = np.zeros((len(ph_values), 48))
for i in range(12):
    Y[:, i] = beta[i]
    Y[:, i + 12] = beta[i] * ph_values
    Y[:, i + 24] = beta[i] * rpm_values
    Y[:, i + 36] = beta[i] * h2o2_concentration

# 计算P参数矩阵
P = pinv(Y.T @ Y) @ Y.T @ error

# 模型预测
ph_test = 12.63
rpm_test = 200
h2o2_test = 0.8

# 机理部分计算
dissociation_degree_test = 10**(11.73 - ph_test)
alpha_test = 1 / (1 + dissociation_degree_test)
ooh_concentration_test = alpha_test * h2o2_test
k_appi_test = reaction_rate_constant_no_ooh * ooh_concentration_test

# 液膜更新时间再计算
liquid_film_update_time_test = (outer_radius - inner_radius) / (0.02107 * (L**0.2279) * ((average_radius * rpm_test)**0.5448) * ns)

# 液膜传质系数计算
kl1_test = (np.sqrt(diffusion_coefficient_no * k_appi_test) / liquid_film_update_time_test) * (
    liquid_film_update_time_test * erf(np.sqrt(k_appi_test * liquid_film_update_time_test)) +
    np.sqrt((liquid_film_update_time_test / np.pi) / k_appi_test) * np.exp(-k_appi_test * liquid_film_update_time_test) +
    (0.5 / k_appi_test) * erf(np.sqrt(k_appi_test * liquid_film_update_time_test))
)
ky_calculated_test = 0.082 * 298.15 * 0.2700 * kl1_test
yno_test = 1 / (a1 * np.exp(a2 * ky_calculated_test) + 1)

# 模糊模型部分计算
y_test = np.zeros(12)
for i in range(12):
    y_test[i] = beta[i].mean() * (P[i] + P[i+12] * ph_test + P[i+24] * rpm_test + P[i+36] * h2o2_test)

yyy_test = np.sum(y_test)

# 计算脱除效率
final_y = yno_test + yyy_test
y_removal_efficiency = 1 - (final_y / y_in)

# 输出结果
print("yyy_test:", yyy_test)
print("final_y:", final_y)
print("y_removal_efficiency:", y_removal_efficiency)
