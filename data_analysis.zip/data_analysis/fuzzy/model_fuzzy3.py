import numpy as np
from scipy.special import erf
from scipy.linalg import pinv
import pandas as pd

# 定义物理常数和参数
num_samples = 31
inner_radius = 42e-3
outer_radius = 146e-3
height = 20e-3
pressure = 101.325 # kPa
henry_constant = 375.28 # kPa*m3/mol

# 进液流量 (m3/s)
liquid_flow_rate = 20e-3 / 3600

# 填料比表面积 (m2/m3)
specific_surface_area = 500

# 填料体积 (m3)
packing_volume = 3.14 * (outer_radius**2 - inner_radius**2) * height

# 有效比表面积 (m2)
effective_surface_area = specific_surface_area * packing_volume
L = liquid_flow_rate / effective_surface_area

# NO与OOH反应速率常数
reaction_rate_constant_no_ooh = 103.4

# NO在溶液中的扩散系数 (m2/s)
diffusion_coefficient_no = 2.21e-9

# 几何平均半径 (m)
average_radius = np.sqrt(inner_radius * outer_radius)

# 进气流量 (m3/s)
gas_flow_rate_n2 = 2 / 3600

# 初始气体浓度
y_in = 0.0005
a1 = (1 - y_in) / y_in
a2 = specific_surface_area * 3.14 * height * (outer_radius**2 - inner_radius**2) / gas_flow_rate_n2

# 读取数据
data = pd.read_excel('no.xlsx')
# print(data.head())
rpm_values = data['rpm']
ph_values = data['ph']
h2o2_concentration = data['ch2o2']
flow_rate = data['flow_rate']
measured_y = data['y']

# 计算出口浓度y_out
y_out = y_in * (1 - measured_y)

# 计算不同pH下的解离程度
dissociation_degree = 10**(11.73 - ph_values)
alpha = 1 / (1 + dissociation_degree)

# 氢过氧负离子浓度
ooh_concentration = h2o2_concentration * alpha

# 表观速率常数
apparent_rate_constant = reaction_rate_constant_no_ooh * ooh_concentration

# 液膜更新时间计算
liquid_film_update_time = (outer_radius - inner_radius) / (0.02107 * (L**0.2279) * ((average_radius * rpm_values)**0.5448) * num_samples)

# 液膜传质系数
kl1 = (np.sqrt(diffusion_coefficient_no * apparent_rate_constant) / liquid_film_update_time) * (
    liquid_film_update_time * erf(np.sqrt(apparent_rate_constant * liquid_film_update_time)) +
    np.sqrt((liquid_film_update_time / np.pi) / apparent_rate_constant) * np.exp(-apparent_rate_constant * liquid_film_update_time) +
    (0.5 / apparent_rate_constant) * erf(np.sqrt(apparent_rate_constant * liquid_film_update_time))
)
ky_calculated = 0.082 * 298.15 * 0.2700 * kl1
yno_calculated = 1 / (a1 * np.exp(a2 * ky_calculated) + 1)

# 实验值与拟合值之间的差异
error = y_out - yno_calculated

# print("yno_calculated:", yno_calculated)
# print("error:", error)

# 定义模糊隶属函数
def trimf(x, abc):
    a, b, c = abc
    return np.maximum(np.minimum((x - a) / (b - a), (c - x) / (c - b)), 0)

# pH值模糊化
y1 = trimf(ph_values, [11.3, 11.8, 12.45])
y2 = trimf(ph_values, [12.3, 12.9, 13.7])

# 转速模糊化
y3 = trimf(rpm_values, [190, 495, 760])
y4 = trimf(rpm_values, [750, 1320, 1700])

# H2O2浓度模糊化
y5 = trimf(h2o2_concentration, [0, 0.2, 0.5])
y6 = trimf(h2o2_concentration, [0.4, 0.65, 0.85])
y7 = trimf(h2o2_concentration, [0.8, 1.2, 1.70])

# Flowrate模糊化 (根据提供的隶属度图)
y8 = trimf(flow_rate, [1, 1.5, 2])  # small
y9 = trimf(flow_rate, [2, 2.5, 3])  # big

# 模糊规则隶属度 (包括flowrate参数)
membership1 = y1 * y3 * y5 * y8
membership2 = y1 * y3 * y6 * y8
membership3 = y1 * y3 * y7 * y8
membership4 = y1 * y4 * y5 * y8
membership5 = y1 * y4 * y6 * y8
membership6 = y1 * y4 * y7 * y8

membership7 = y2 * y3 * y5 * y8
membership8 = y2 * y3 * y6 * y8
membership9 = y2 * y3 * y7 * y8
membership10 = y2 * y4 * y5 * y8
membership11 = y2 * y4 * y6 * y8
membership12 = y2 * y4 * y7 * y8

membership13 = y1 * y3 * y5 * y9
membership14 = y1 * y3 * y6 * y9
membership15 = y1 * y3 * y7 * y9
membership16 = y1 * y4 * y5 * y9
membership17 = y1 * y4 * y6 * y9
membership18 = y1 * y4 * y7 * y9

membership19 = y2 * y3 * y5 * y9
membership20 = y2 * y3 * y6 * y9
membership21 = y2 * y3 * y7 * y9
membership22 = y2 * y4 * y5 * y9
membership23 = y2 * y4 * y6 * y9
membership24 = y2 * y4 * y7 * y9

def replace_zeros(array, epsilon=1e-5):
    return np.where(array == 0, epsilon, array)

# 计算模糊规则隶属度和模型系数
denominator = (membership1 + membership2 + membership3 + membership4 + membership5 + membership6 +
              membership7 + membership8 + membership9 + membership10 + membership11 + membership12 +
              membership13 + membership14 + membership15 + membership16 + membership17 + membership18 +
              membership19 + membership20 + membership21 + membership22 + membership23 + membership24)

denominator = replace_zeros(denominator)

beta = np.zeros((24, len(ph_values)))
for i in range(24):
    beta[i] = locals()[f'membership{i+1}'] / denominator

# 模型矩阵构建 (扩展到包含flowrate)
Y = np.zeros((len(ph_values), 120))
for i in range(24):
    Y[:, i] = beta[i]
    Y[:, i + 24] = beta[i] * ph_values
    Y[:, i + 48] = beta[i] * rpm_values
    Y[:, i + 72] = beta[i] * h2o2_concentration
    Y[:, i + 96] = beta[i] * flow_rate

# print("Y shape:", Y.shape)
# print("error shape:", error.shape)
# print("NaN in Y:", np.isnan(Y).any())
# print("NaN in error:", np.isnan(error).any())
# print("Inf in Y:", np.isinf(Y).any())
# print("Inf in error:", np.isinf(error).any())

# 计算P参数矩阵
P = pinv(Y.T @ Y) @ Y.T @ error

# 模型预测
ph_test = 12.63
rpm_test = 1200
h2o2_test = 0.8
flowrate_test = 1.5

# 机理部分计算
dissociation_degree_test = 10**(11.73 - ph_test)
alpha_test = 1 / (1 + dissociation_degree_test)
ooh_concentration_test = alpha_test * h2o2_test
k_appi_test = reaction_rate_constant_no_ooh * ooh_concentration_test

# 液膜更新时间再计算
liquid_film_update_time_test = (outer_radius - inner_radius) / (0.02107 * (L**0.2279) * ((average_radius * rpm_test)**0.5448) * num_samples)

# 液膜传质系数计算
kl1_test = (np.sqrt(diffusion_coefficient_no * k_appi_test) / liquid_film_update_time_test) * (
    liquid_film_update_time_test * erf(np.sqrt(k_appi_test * liquid_film_update_time_test)) +
    np.sqrt((liquid_film_update_time_test / np.pi) / k_appi_test) * np.exp(-k_appi_test * liquid_film_update_time_test) +
    (0.5 / k_appi_test) * erf(np.sqrt(k_appi_test * liquid_film_update_time_test))
)
ky_calculated_test = 0.082 * 298.15 * 0.2700 * kl1_test
yno_test = 1 / (a1 * np.exp(a2 * ky_calculated_test) + 1)

# 模糊模型部分计算
y_test = np.zeros(24)
for i in range(24):
    y_test[i] = beta[i].mean() * (P[i] + P[i+24] * ph_test + P[i+48] * rpm_test + P[i+72] * h2o2_test)

yyy_test = -np.sum(y_test)

# 计算脱除效率
final_y = yno_test + yyy_test
y_removal_efficiency = 1 - (final_y / y_in)

# 输出结果
print("yyy_test:", yyy_test)
print("final_y:", final_y)
print("y_removal_efficiency:", y_removal_efficiency)
